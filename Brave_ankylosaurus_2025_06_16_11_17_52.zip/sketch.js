let truck, city, farm, crops = [], clouds = [], points = 0, timer = 15, gameOver = false, lastTime = 0;
let resetButton;

class Cloud {
  constructor() {
    this.x = random(-100, width);
    this.y = random(50, height/2 - 50);
    this.speed = random(0.2, 0.5);
    this.size = random(30, 60);
  }
  move() {
    this.x += this.speed;
    if (this.x > width + 100) this.x = -100;
  }
  display() {
    fill(255, 255, 255, 200);
    noStroke();
    ellipse(this.x, this.y, this.size, this.size/1.5);
    ellipse(this.x + this.size/3, this.y - this.size/6, this.size/1.5, this.size/2);
    ellipse(this.x - this.size/3, this.y, this.size/1.5, this.size/2);
  }
}

class Truck {
  constructor() {
    this.x = 50;
    this.y = height/2 + 50;
    this.speed = 5;
    this.width = 40;
    this.height = 30;
  }
  move() {
    if (keyIsDown(LEFT_ARROW)) this.x = max(0, this.x - this.speed);
    if (keyIsDown(RIGHT_ARROW)) this.x = min(width - this.width, this.x + this.speed);
    if (keyIsDown(UP_ARROW)) this.y = max(height/2, this.y - this.speed);
    if (keyIsDown(DOWN_ARROW)) this.y = min(height - this.height, this.y + this.speed);
  }
  display() {
    fill(30, 144, 255);
    rect(this.x, this.y, this.width, this.height);
    fill(70, 130, 180);
    rect(this.x + this.width - 15, this.y - 10, 15, 10);
    fill(0);
    ellipse(this.x + 10, this.y + this.height, 12, 12);
    ellipse(this.x + this.width - 10, this.y + this.height, 12, 12);
  }
}

class City {
  constructor(x,y) {
    this.x = x;
    this.y = y;
    this.width = 100;
    this.height = 100;
  }
  display() {
    fill(70, 70, 70);
    rect(this.x, this.y + 30, this.width, this.height - 30);
    fill(100, 100, 120);
    rect(this.x + 10, this.y + 10, 20, 50);
    rect(this.x + 40, this.y, 25, 80);
    rect(this.x + 75, this.y + 20, 20, 60);
    fill(255, 255, 0);
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 2; j++) {
        rect(this.x + 15 + i*30, this.y + 20 + j*20, 5, 5);
      }
    }
    fill(255);
    textSize(12);
    text("CIDADE", this.x + 30, this.y + this.height - 10);
  }
  checkDelivery(truck) {
    return truck.x + truck.width > this.x && truck.x < this.x + this.width && 
           truck.y + truck.height > this.y && truck.y < this.y + this.height;
  }
}

class Farm {
  constructor(x,y) {
    this.x = x;
    this.y = y;
    this.width = 80;
    this.height = 80;
  }
  display() {
    fill(160, 82, 45);
    rect(this.x, this.y + 20, this.width, this.height - 20);
    fill(139, 69, 19);
    triangle(this.x, this.y + 20, this.x + this.width/2, this.y, this.x + this.width, this.y + 20);
    fill(101, 67, 33);
    rect(this.x + this.width/2 - 10, this.y + 50, 20, 30);
    fill(240, 240, 240);
    rect(this.x + 15, this.y + 40, 20, 15);
    fill(255);
    textSize(12);
    text("FAZENDA", this.x + 15, this.y + this.height - 5);
  }
}

class Crop {
  constructor(x,y,type) {
    this.x = x;
    this.y = y;
    this.type = type || floor(random(1, 5));
    this.size = random(15, 25);
  }
  display() {
    switch(this.type) {
      case 1: // Wheat
        fill(210, 180, 140);
        rect(this.x + this.size/2 - 2, this.y + this.size/2, 4, this.size);
        fill(255, 215, 0);
        for (let i = 0; i < 3; i++) {
          ellipse(this.x + this.size/2, this.y + i*5, this.size/2, this.size/3);
        }
        break;
      case 2: // Corn
        fill(34, 139, 34);
        rect(this.x + this.size/2 - 1, this.y + this.size/2, 2, this.size);
        fill(255, 255, 0);
        ellipse(this.x + this.size/2, this.y + this.size/3, this.size/1.5, this.size/2);
        break;
      case 3: // Carrot
        fill(255, 165, 0);
        triangle(this.x + this.size/2, this.y, this.x, this.y + this.size, this.x + this.size, this.y + this.size);
        fill(34, 139, 34);
        rect(this.x + this.size/2 - 1, this.y, 2, this.size/3);
        break;
      case 4: // Potato
        fill(139, 69, 19);
        ellipse(this.x + this.size/2, this.y + this.size/2, this.size, this.size/1.5);
        fill(34, 139, 34);
        rect(this.x + this.size/2 - 1, this.y, 2, this.size/3);
        break;
    }
  }
  checkCollection(truck) {
    return truck.x + truck.width > this.x && truck.x < this.x + this.size && 
           truck.y + truck.height > this.y && truck.y < this.y + this.size;
  }
}

function resetGame() {
  points = 0;
  timer = 15;
  gameOver = false;
  lastTime = millis();
  truck = new Truck();
  crops = [];
  
  // Spawn crops everywhere - near farm, middle, and city
  for (let i = 0; i < 12; i++) {
    let area = floor(random(3)); // 0=farm, 1=middle, 2=city
    let x, y;
    
    if (area === 0) { // Near farm
      x = random(100, width/3);
    } else if (area === 1) { // Middle
      x = random(width/3, 2*width/3);
    } else { // Near city
      x = random(2*width/3, width - 100);
    }
    
    y = random(height/2 + 50, height - 50);
    crops.push(new Crop(x, y));
  }
}

function updateTimer() {
  if (millis() - lastTime >= 1000) {
    timer--;
    lastTime = millis();
    if (timer <= 0) gameOver = true;
  }
  fill(0);
  textSize(16);
  text("Tempo: "+timer, 20, 30);
  text("Pontos: "+points, 20, 60);
}

function setup() {
  createCanvas(600,400);
  
  resetButton = createButton('Reiniciar Jogo');
  resetButton.position(width/2 - 70, height/2 + 60);
  resetButton.size(140, 40);
  resetButton.style('font-size', '16px');
  resetButton.style('background-color', '#4CAF50');
  resetButton.style('color', 'white');
  resetButton.style('border', 'none');
  resetButton.style('border-radius', '5px');
  resetButton.hide();
  resetButton.mousePressed(resetGame);
  
  city = new City(width-130, height/2+20);
  farm = new Farm(30, height/2+30);
  
  resetGame();
  
  for (let i=0; i<5; i++) clouds.push(new Cloud());
}

function draw() {
  // Sky gradient
  for (let y = 0; y < height/2; y++) {
    let c = lerpColor(color(135, 206, 235), color(30, 144, 255), y/(height/2));
    stroke(c);
    line(0, y, width, y);
  }
  
  // Grass gradient
  for (let y = height/2; y < height; y++) {
    let c = lerpColor(color(34, 139, 34), color(0, 100, 0), (y-height/2)/(height/2));
    stroke(c);
    line(0, y, width, y);
  }
  
  for (let cloud of clouds) {
    cloud.move();
    cloud.display();
  }
  
  if (gameOver) {
    fill(0, 0, 0, 200);
    rect(width/2 - 150, height/2 - 60, 300, 120, 20);
    fill(255);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Fim de Jogo!", width/2, height/2 - 20);
    textSize(24);
    text("Pontos: "+points, width/2, height/2 + 10);
    
    resetButton.show();
    return;
  } else {
    resetButton.hide();
  }
  
  truck.move();
  truck.display();
  
  for (let i = crops.length - 1; i >= 0; i--) {
    crops[i].display();
    if (crops[i].checkCollection(truck)) {
      crops.splice(i, 1);
      points += 10;
    }
  }
  
  city.display();
  farm.display();
  
  if (city.checkDelivery(truck) && crops.length === 0) {
    points += 50;
    crops = [];
    // When respawning, distribute crops everywhere again
    for (let i = 0; i < 12; i++) {
      let area = floor(random(3));
      let x, y;
      
      if (area === 0) {
        x = random(100, width/3);
      } else if (area === 1) {
        x = random(width/3, 2*width/3);
      } else {
        x = random(2*width/3, width - 100);
      }
      
      y = random(height/2 + 50, height - 50);
      crops.push(new Crop(x, y));
    }
    truck.x = 50;
    truck.y = height/2 + 50;
    timer = 15;
    lastTime = millis();
  }
  
  updateTimer();
}